// 外部 JS（MV3 允许），作为 meta refresh 的双保险
window.location.replace("https://jianye.pages.dev/homepage");
